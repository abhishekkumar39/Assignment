﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_Application
{
    public partial class Deposite : Form
    {
        public Deposite()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bank bank = new Bank();
            bank.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal depositAmount;

            if (decimal.TryParse(textBox1.Text, out depositAmount) && depositAmount > 0)
            {
                Balance balance = new Balance(depositAmount);
                balance.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter a valid deposit amount.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void Deposite_Load(object sender, EventArgs e)
        {
            this.label1.Text = Program.Name;
        }
    }  
}
