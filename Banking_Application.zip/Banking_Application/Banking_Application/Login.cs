﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL_Bank;
using DAL_Banl;

namespace Banking_Application
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Transection ob = new Transection();
            bool ret = ob.DoLogin(comboBox1.Text, textBox1.Text);
            if (ret)
            {
                Bank bank = new Bank();
                BanK obank = ob.FetchOptions(comboBox1.Text, textBox1.Text);
                Program.Name=obank.First_Name+" "+obank.Last_Name;
                Program.Balance=obank.Balance;
                bank.Show();
            }
            else
            {
                MessageBox.Show("Invalid Account Or Password");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
